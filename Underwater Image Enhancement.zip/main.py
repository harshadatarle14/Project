import streamlit as st
from PIL import Image, ImageStat, ImageFilter, ImageOps
import numpy as np
import time
import hashlib
import sqlite3 


conn = sqlite3.connect('data.db')
c = conn.cursor()

def make_hashes(password):
    return hashlib.sha256(str.encode(password)).hexdigest()


def check_hashes(password,hashed_text):
    if make_hashes(password) == hashed_text:
        return hashed_text
    return False


def create_usertable():
    c.execute('CREATE TABLE IF NOT EXISTS userstable(username TEXT,password TEXT)')


def add_userdata(username,password):
    c.execute('INSERT INTO userstable(username,password) VALUES (?,?)',(username,password))
    conn.commit()

def login_user(username,password):
    c.execute('SELECT * FROM userstable WHERE username =? AND password = ?',(username,password))
    data = c.fetchall()
    return data


def view_all_users():
    c.execute('SELECT * FROM userstable')
    data = c.fetchall()
    return data

def image_enhancer():
    file = st.file_uploader("Please upload a RGB underwater image file", type=["jpg", "png"])
    if file is None:
        st.text("Please upload an image file")
    else:
        image = Image.open(file)
        if image.mode != 'RGB':
            st.text("Please upload RGB image")
        else:
            st.text("Uploaded Image")
            st.image(image, use_column_width=True)
            imtype = st.radio("Select one", ('Greenish Image', 'Bluish Image'))
            if imtype == "Greenish Image":
                flag=0
            else:
                flag=1
            if(st.button("Enhance Uploaded Image")):
                averagefused = underwater_image_enhancement(image, flag)
                st.text("Enhanced Image Using Averaging Based Fusion")
                st.image(averagefused, use_column_width=True)


def color_correction(image, flag):
    imager, imageg, imageb = image.split()
    
    minR, maxR = imager.getextrema()
    minG, maxG = imageg.getextrema()
    minB, maxB = imageb.getextrema()
    
    imageR = np.array(imager,np.float64)
    imageG = np.array(imageg,np.float64)
    imageB = np.array(imageb,np.float64)
    
    x,y = image.size
    
    for i in range(0, y):
        for j in range(0, x):
            imageR[i][j]=(imageR[i][j]-minR)/(maxR-minR)
            imageG[i][j]=(imageG[i][j]-minG)/(maxG-minG)
            imageB[i][j]=(imageB[i][j]-minB)/(maxB-minB)
    
    meanR=np.mean(imageR)
    meanG=np.mean(imageG)
    meanB=np.mean(imageB)
    

    if flag == 0:
        for i in range(y):
            for j in range(x):
                imageR[i][j]=int((imageR[i][j]+(meanG-meanR)*(1-imageR[i][j])*imageG[i][j])*maxR)
                imageB[i][j]=int((imageB[i][j]+(meanG-meanB)*(1-imageB[i][j])*imageG[i][j])*maxB)

        for i in range(0, y):
            for j in range(0, x):
                imageG[i][j]=int(imageG[i][j]*maxG)
   
    if flag == 1:
        for i in range(y):
            for j in range(x):
                imageR[i][j]=int((imageR[i][j]+(meanG-meanR)*(1-imageR[i][j])*imageG[i][j])*maxR)

        for i in range(0, y):
            for j in range(0, x):
                imageB[i][j]=int(imageB[i][j]*maxB)
                imageG[i][j]=int(imageG[i][j]*maxG)
            
    compensateIm = np.zeros((y, x, 3), dtype = "uint8")
    compensateIm[:, :, 0]= imageR;
    compensateIm[:, :, 1]= imageG;
    compensateIm[:, :, 2]= imageB;

    compensateIm=Image.fromarray(compensateIm)
    
    return compensateIm


def gray_world(image):
    imager, imageg, imageb = image.split()
    imagegray=image.convert('L')
    
    imageR = np.array(imager,np.float64)
    imageG = np.array(imageg,np.float64)
    imageB = np.array(imageb,np.float64)
    imageGray=np.array(imagegray, np.float64)
    
    x,y = image.size
      
    meanR=np.mean(imageR)
    meanG=np.mean(imageG)
    meanB=np.mean(imageB)
    meanGray=np.mean(imageGray)
    
    for i in range(0, y):
        for j in range(0, x):
            imageR[i][j]=int(imageR[i][j]*meanGray/meanR)
            imageG[i][j]=int(imageG[i][j]*meanGray/meanG)
            imageB[i][j]=int(imageB[i][j]*meanGray/meanB)
    
    whitebalancedIm = np.zeros((y, x, 3), dtype = "uint8")
    whitebalancedIm[:, :, 0]= imageR;
    whitebalancedIm[:, :, 1]= imageG;
    whitebalancedIm[:, :, 2]= imageB;
    return Image.fromarray(whitebalancedIm)



def sharpen(wbimage, original):
    smoothed_image = wbimage.filter(ImageFilter.GaussianBlur)
    smoothedr, smoothedg, smoothedb = smoothed_image.split()
    

    imager, imageg, imageb = wbimage.split()
    imageR = np.array(imager,np.float64)
    imageG = np.array(imageg,np.float64)
    imageB = np.array(imageb,np.float64)
    smoothedR = np.array(smoothedr,np.float64)
    smoothedG = np.array(smoothedg,np.float64)
    smoothedB = np.array(smoothedb,np.float64)
    
    x, y=wbimage.size
    
    for i in range(y):
        for j in range(x):
            imageR[i][j]=2*imageR[i][j]-smoothedR[i][j]
            imageG[i][j]=2*imageG[i][j]-smoothedG[i][j]
            imageB[i][j]=2*imageB[i][j]-smoothedB[i][j]
    
    sharpenIm = np.zeros((y, x, 3), dtype = "uint8")         
    sharpenIm[:, :, 0]= imageR;
    sharpenIm[:, :, 1]= imageG;
    sharpenIm[:, :, 2]= imageB; 
    return Image.fromarray(sharpenIm)


def hsv_global_equalization(image):
    hsvimage = image.convert('HSV')
    Hue, Saturation, Value = hsvimage.split()
    equalizedValue = ImageOps.equalize(Value, mask = None)
    x, y = image.size
    equalizedIm = np.zeros((y, x, 3), dtype = "uint8")
    equalizedIm[:, :, 0]= Hue;
    equalizedIm[:, :, 1]= Saturation;
    equalizedIm[:, :, 2]= equalizedValue;
    hsvimage = Image.fromarray(equalizedIm, 'HSV') 
    rgbimage = hsvimage.convert('RGB')
    return rgbimage

    """Average-based fusion of a sharpened image and a contrast-enhanced image is a technique used to combine the beneficial aspects of both processing methods. In this method, the sharpened image, which enhances edge clarity and detail, and the contrast-enhanced image, which improves the overall contrast and dynamic range, are fused together by taking the average pixel values at each corresponding position. By blending the two images through averaging, this fusion approach aims to produce a final image that retains the enhanced sharpness from the sharpened image while also incorporating the improved contrast and tonal range from the contrast-enhanced image. This technique often results in an image with enhanced overall visual quality, with sharper details and improved contrast, suitable for various applications such as medical imaging, remote sensing, and digital photography.
    """
def average_fusion(image1, image2):
    image1r, image1g, image1b = image1.split()
    image2r, image2g, image2b = image2.split()
    image1R = np.array(image1r, np.float64)
    image1G = np.array(image1g, np.float64)
    image1B = np.array(image1b, np.float64)
    image2R = np.array(image2r, np.float64)
    image2G = np.array(image2g, np.float64)
    image2B = np.array(image2b, np.float64)
    
    x, y = image1R.shape
    for i in range(x):
        for j in range(y):
            image1R[i][j]= int((image1R[i][j]+image2R[i][j])/2)
            image1G[i][j]= int((image1G[i][j]+image2G[i][j])/2)
            image1B[i][j]= int((image1B[i][j]+image2B[i][j])/2)
    fusedIm = np.zeros((x, y, 3), dtype = "uint8")
    fusedIm[:, :, 0]= image1R;
    fusedIm[:, :, 1]= image1G;
    fusedIm[:, :, 2]= image1B;
    return Image.fromarray(fusedIm)
    


def underwater_image_enhancement(image, flag):
    with st.spinner('Color Correction Based on Green Channel...'):
        compensatedimage=color_correction(image, flag)  
        
    with st.spinner('White Balancing the color corrected Image using Grayworld Algorithm...'):
        whitebalanced=gray_world(compensatedimage)
    
    with st.spinner('Enhancing Contrast of White Balanced Image using Global Histogram Equalization...'):
        contrastenhanced = hsv_global_equalization(whitebalanced)
    
    with st.spinner('Sharpening White Balanced Image using Unsharp Masking...'):
        sharpenedimage=sharpen(whitebalanced, image)
    
    with st.spinner('Performing Average Based Fusion of Sharped Image & Contrast Enhanced Image...'):
        averagefused =  average_fusion(sharpenedimage, contrastenhanced)

    return averagefused

def main():
    st.subheader('Underwater Image Enhancement based on Dehazing and Color Correction')
    st.sidebar.subheader("Matoshri College of Engineering and Research Centre, Nashik")
    st.sidebar.subheader("Department of Information Technology")
    menu = ["Home","Login","SignUp"]
    choice = st.sidebar.selectbox("Menu",menu)
    if choice == "Home":
        st.image("Architecture.png")
        st.markdown('<div style="text-align: justify;">Underwater image enhancement techniques leveraging dehazing and color correction algorithms have revolutionized underwater photography and imaging systems. By addressing the challenges posed by waters inherent light absorption and scattering properties, these methods significantly improve image clarity, contrast, and color fidelity. Dehazing algorithms effectively mitigate the effects of water turbidity, enhancing visibility by removing haze and restoring image details lost in the underwater environment. Concurrently, color correction techniques compensate for the color cast caused by waters selective absorption, restoring accurate color representation to underwater scenes. Through the synergistic application of dehazing and color correction, these enhancement approaches not only enhance the aesthetic appeal of underwater images but also facilitate scientific research, marine exploration, and various underwater applications across diverse domains. </div><br>', unsafe_allow_html=True)
    
    elif choice == "Login":
        st.sidebar.subheader("Please Enter Valid Credentials")

        username = st.sidebar.text_input("User Name")
        password = st.sidebar.text_input("Password",type='password')
        
        if st.sidebar.checkbox("Login/Logout"):
            create_usertable()
            hashed_pswd = make_hashes(password)
            result = login_user(username,check_hashes(password,hashed_pswd))
            if result:
                st.sidebar.success("Login Success")    
                image_enhancer()
            else:
                st.warning("Incorrect Username/Password")
        else:
            st.warning("Incorrect Username/Password")
            
    elif choice == "SignUp":
        st.subheader("Create New Account")
        new_user = st.text_input("Username")
        new_password = st.text_input("Password",type='password')

        if st.button("Signup"):
            if new_user != '' and new_password!='':
                create_usertable()
                add_userdata(new_user,make_hashes(new_password))
                st.success("You have successfully created a valid Account")
                st.info("Go to Login Menu to login")
            else:
                st.warning("Please Enter valid Data")

if __name__ == '__main__':
	main()